import React from 'react'

const Notfound = () => {
  return (
    <>
      <p className='red'>City name not found</p> 
    </>
  )
}

export default Notfound