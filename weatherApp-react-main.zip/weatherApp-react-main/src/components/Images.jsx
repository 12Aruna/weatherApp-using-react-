import React from 'react'
import clouds from '../Assets/weather/clouds.jpg'
import clear from '../Assets/weather/clear.jpg'
import drizzle from '../Assets/weather/drizzle.jpg'
import snow from '../Assets/weather/snow.jpg'
import rain from '../Assets/weather/rain.jpg'
import thunderstorm from '../Assets/weather/thunderstorm.jpg'
import nf from '../Assets/weather/nf.jpg'


const Images = {
    clouds,
    clear,
    drizzle,
    snow,
    rain,
    thunderstorm,
    nf,

}
export default Images;